package com.beatapasta.drinkalert;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KdsAccessibilityService extends AccessibilityService {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> notifiedOrders = new HashSet<>();
    private String lastScreenSignature = "";

    private static final Pattern ORDER_PATTERN =
            Pattern.compile("Orden\\s+\\d+([\\s\\S]*?)(?=Orden\\s+\\d+|$)",
                    Pattern.CASE_INSENSITIVE);

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!"com.android.chrome".equals(event.getPackageName())) return;

        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::scanKds, 300);
    }

    private void scanKds() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        StringBuilder text = new StringBuilder();
        collectText(root, text);

        String screen = text.toString().replaceAll("\\s+", " ").trim();
        if (screen.equals(lastScreenSignature)) return;
        lastScreenSignature = screen;

        Matcher matcher = ORDER_PATTERN.matcher(text.toString());
        while (matcher.find()) {
            String block = matcher.group().replaceAll("\\s+", " ").trim();

            // The KDS screenshot shows "LOCAL" and "Orden X".
            // We use the complete order block minus changing timers as the MVP signature.
            String stable = block
                    .replaceAll("\\b\\d{1,2}:\\d{2}\\b", "")
                    .replaceAll("\\b\\d{1,2}\\s*segundos\\b", "")
                    .replaceAll("\\s+", " ")
                    .trim();

            if (stable.length() < 10) continue;

            String key = Integer.toHexString(stable.hashCode());
            if (notifiedOrders.add(key)) {
                String body = buildReadableOrder(stable);
                MainActivity.showNotification(
                        this,
                        "🔔 Nuovo ordine bevande",
                        body);
            }
        }
    }

    private String buildReadableOrder(String block) {
        // Keep the raw KDS text for now; later we will parse table + products precisely.
        return block.length() > 180 ? block.substring(0, 180) : block;
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder out) {
        if (node == null) return;

        CharSequence t = node.getText();
        if (t != null && t.length() > 0) {
            out.append(t).append('\n');
        }

        CharSequence d = node.getContentDescription();
        if (d != null && d.length() > 0) {
            out.append(d).append('\n');
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectText(child, out);
                child.recycle();
            }
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
    }

    @Override
    public void onInterrupt() {
        // Nothing to do.
    }
}
