# DrinkAlert — MVP 0.1

Questo è il primo prototipo per il KDS del ristorante.

## Obiettivo della prima prova

Il tablet Android apre il KDS in Chrome. DrinkAlert usa un AccessibilityService
per leggere il contenuto testuale della pagina e cercare nuove schede "Orden ...".

Quando rileva una nuova scheda, mostra una notifica Android sul dispositivo.

### Perché questa prova viene prima

Prima di costruire la parte cloud/telefono dobbiamo verificare che Chrome
esponga davvero il testo del KDS all'AccessibilityService. Android permette a un
AccessibilityService configurato per recuperare il contenuto della finestra di
leggere la gerarchia dei nodi dell'app attiva.

## Installazione

1. Aprire il progetto in Android Studio.
2. Compilare e installare l'APK sul tablet.
3. Aprire DrinkAlert.
4. Premere "Apri Accessibilità".
5. Attivare DrinkAlert.
6. Tornare in Chrome e aprire il KDS.
7. Premere "Testa notifica" per verificare le notifiche.
8. Far arrivare un ordine reale e controllare se viene rilevato.

## Prossima versione

Dopo la prova sul tablet:
- parsing preciso di tavolo/prodotti;
- deduplicazione robusta degli ordini;
- invio dell'ordine a un backend;
- Firebase Cloud Messaging per notificare il telefono;
- registrazione di più telefoni/camerieri;
- storico degli ordini.

NOTA: l'AccessibilityService è usato qui come prototipo tecnico per leggere il
KDS. Se l'app dovesse essere pubblicata su Google Play, bisogna rispettare le
regole e le limitazioni di Google sugli AccessibilityService. Per una soluzione
interna al ristorante, la distribuzione privata/sideloading è una strada diversa.
